// Octopart Content Script
// Provides atomic search operations for the BOM-to-Cart Chrome extension.
// Runs on https://octopart.com/*
// Path: /root/bom-to-cart-extension/content/octopart.js

(() => {
  'use strict';

  // ── Message handler ──────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    const { action, payload } = msg || {};
    if (!action) return;

    const handlers = {
      search: doSearch,
      getSearchResults: getSearchResults,
      navigateToPart: navigateToPart,
      getPricingTable: getPricingTable,
      clickShowAll: clickShowAll,
      detectCaptcha: detectCaptcha,
      getPageInfo: getPageInfo
    };

    const fn = handlers[action];
    if (fn) {
      fn(payload).then(sendResponse, e => sendResponse({ error: e.message }));
      return true; // async
    }
  });

  // ── Atomic Operations ────────────────────────────────────

  /** Navigate to Octopart search page for a query */
  async function doSearch({ query, currency = 'USD' }) {
    const url = `https://octopart.com/search?q=${encodeURIComponent(query)}&currency=${currency}&specs=0`;
    window.location.href = url;
    return { action: 'navigated', url };
  }

  /** Extract search result cards from the current search page */
  async function getSearchResults() {
    await waitForSelector('a[href*="/part/"]', 8000);

    const cards = [];
    document.querySelectorAll('a[href*="/part/"]').forEach(link => {
      const container = link.closest('li, div[data-testid], article') || link.parentElement;
      const text = container?.textContent?.trim()?.substring(0, 200) || '';
      const href = link.getAttribute('href');
      // Deduplicate
      if (!cards.find(c => c.href === href)) {
        cards.push({ href, text });
      }
    });

    return { url: window.location.href, results: cards.slice(0, 10), total: cards.length };
  }

  /** Navigate to a specific part detail page */
  async function navigateToPart({ url }) {
    window.location.href = url;
    return { action: 'navigated', url };
  }

  /** Extract the pricing table from the part detail page */
  async function getPricingTable() {
    await waitForSelector('tbody tr', 8000);

    const rows = document.querySelectorAll('tbody tr');
    const suppliers = [];

    rows.forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length < 8) return;

      const distributor = cells[1]?.textContent?.trim();
      const unitPrice = cells[7]?.textContent?.trim()?.replace(/\*$/, '').replace(/[^\d.]/g, '');

      if (distributor && unitPrice && distributor !== 'Distributor') {
        suppliers.push({ distributor, unit_price: parseFloat(unitPrice) });
      }
    });

    return { url: window.location.href, suppliers, count: suppliers.length };
  }

  /** Click "Show All" button to reveal all suppliers */
  async function clickShowAll() {
    const btn = Array.from(document.querySelectorAll('button, a'))
      .find(el => el.textContent.trim() === 'Show All');

    if (!btn) return { clicked: false, reason: 'No "Show All" button found' };

    btn.click();
    await sleep(2000);
    return { clicked: true };
  }

  /** Detect if CAPTCHA / security check is present */
  async function detectCaptcha() {
    const pageText = document.body.textContent.toLowerCase();
    const indicators = [
      'one more step',
      'security check',
      'complete the security',
      'press & hold',
      'verify you are human',
      'please verify',
      'captcha'
    ];

    const found = indicators.filter(ind => pageText.includes(ind));
    return {
      captcha: found.length > 0,
      indicators: found,
      url: window.location.href
    };
  }

  /** Get basic page info for agent diagnostics */
  async function getPageInfo() {
    return {
      url: window.location.href,
      title: document.title,
      bodyPreview: document.body.textContent.trim().substring(0, 500),
      readyState: document.readyState
    };
  }

  // ── Helpers ───────────────────────────────────────────────

  async function waitForSelector(selector, timeout = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const el = document.querySelector(selector);
      if (el) return el;
      await sleep(300);
    }
    throw new Error(`Timeout waiting for "${selector}" on ${window.location.href}`);
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
})();
