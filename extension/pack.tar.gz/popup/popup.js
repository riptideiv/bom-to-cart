// BOM-to-Cart Popup Controller
// Path: /root/bom-to-cart-extension/popup/popup.js

/* global BOMStore */

// ── Init ───────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  initTabs();
  await checkAgentStatus();
  await renderBOMTable();
  bindEvents();
});

// ── Tab Switching ──────────────────────────────────────────
function initTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');

      if (tab.dataset.tab === 'optimize') renderOptimizeTab();
      if (tab.dataset.tab === 'bom') renderBOMTable();
    });
  });
}

// ── Agent Status ───────────────────────────────────────────
async function checkAgentStatus() {
  const el = document.getElementById('agent-status');
  try {
    const resp = await chrome.runtime.sendMessage({ type: 'agent:is-configured' });
    if (resp) {
      el.textContent = 'Agent: ⬤ Ready';
      el.className = 'agent-status online';
    } else {
      el.textContent = 'Agent: ⬤ No API key';
      el.className = 'agent-status offline';
    }
  } catch {
    el.textContent = 'Agent: ⬤ SW error';
    el.className = 'agent-status offline';
  }
}

// ── BOM Table Rendering ───────────────────────────────────
async function renderBOMTable() {
  const stats = await chrome.runtime.sendMessage({ type: 'bom:stats' });
  document.getElementById('bom-stats').textContent =
    `${stats.total} 零件 · ${stats.priced} 已标价 · ${stats.pending} 待搜索`;

  const bom = await chrome.runtime.sendMessage({ type: 'bom:load' });
  const tbody = document.getElementById('bom-tbody');

  if (!bom || !bom.parts.length) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="7">还没有零件。点击 "从文本导入" 或 "添加行"。</td></tr>';
    return;
  }

  tbody.innerHTML = bom.parts.map((p, i) => {
    const priceStr = p.prices && Object.keys(p.prices).length
      ? Object.entries(p.prices).map(([k, v]) => `${k}: $${v}`).join(', ')
      : '—';
    const specsStr = p.specs ? Object.entries(p.specs).map(([k, v]) => `${k}: ${v}`).join(', ') : '';

    return `
      <tr data-id="${p.id}">
        <td>${i + 1}</td>
        <td><input type="text" value="${escAttr(p.name)}" data-field="name" data-id="${p.id}"></td>
        <td><input type="number" value="${p.quantity}" data-field="quantity" data-id="${p.id}" class="inline-qty" min="1"></td>
        <td><input type="text" value="${escAttr(specsStr)}" data-field="specsStr" data-id="${p.id}" style="width:120px"></td>
        <td><span class="status-badge status-${p.status}">${p.status}</span></td>
        <td style="font-size:10px;max-width:120px;overflow:hidden;text-overflow:ellipsis">${escHtml(priceStr)}</td>
        <td>
          <button class="btn-small btn-danger" data-action="delete" data-id="${p.id}">✕</button>
        </td>
      </tr>`;
  }).join('');

  // Inline edit — save on blur/enter
  tbody.querySelectorAll('input').forEach(inp => {
    inp.addEventListener('change', () => saveInlineEdit(inp));
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); inp.blur(); } });
  });

  // Delete buttons
  tbody.querySelectorAll('[data-action="delete"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('删除这个零件？')) return;
      await chrome.runtime.sendMessage({ type: 'bom:remove-part', payload: btn.dataset.id });
      await renderBOMTable();
    });
  });
}

async function saveInlineEdit(inp) {
  const id = inp.dataset.id;
  const field = inp.dataset.field;
  let value = inp.value.trim();

  if (field === 'quantity') {
    value = Math.max(1, parseInt(value) || 1);
    inp.value = value;
    await chrome.runtime.sendMessage({ type: 'bom:update-part', payload: { id, changes: { quantity: value } } });
  } else if (field === 'name') {
    await chrome.runtime.sendMessage({ type: 'bom:update-part', payload: { id, changes: { name: value } } });
  } else if (field === 'specsStr') {
    const specs = {};
    if (value) {
      value.split(',').forEach(pair => {
        const [k, v] = pair.split(':').map(s => s.trim());
        if (k && v !== undefined) specs[k] = v;
      });
    }
    await chrome.runtime.sendMessage({ type: 'bom:update-part', payload: { id, changes: { specs } } });
  }
  await renderBOMTable();
}

// ── Import Flow ────────────────────────────────────────────
function bindEvents() {
  // Import
  document.getElementById('btn-import').addEventListener('click', () => {
    document.getElementById('import-modal').classList.remove('hidden');
  });
  document.getElementById('btn-cancel-import').addEventListener('click', () => {
    document.getElementById('import-modal').classList.add('hidden');
    document.getElementById('import-status').textContent = '';
  });
  document.getElementById('btn-parse').addEventListener('click', handleParseBOM);

  // Clarify
  document.getElementById('btn-clarify-send').addEventListener('click', handleClarifySend);
  document.getElementById('btn-clarify-skip').addEventListener('click', () => {
    document.getElementById('clarify-dialog').classList.add('hidden');
  });

  // Add row
  document.getElementById('btn-add-row').addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'bom:add-part', payload: { name: 'New Part', quantity: 1 } });
    await renderBOMTable();
  });

  // Clear BOM
  document.getElementById('btn-clear-bom').addEventListener('click', async () => {
    if (!confirm('确定要清空整个 BOM 表吗？此操作不可撤销。')) return;
    await chrome.runtime.sendMessage({ type: 'bom:save', payload: { version: '1.0', parts: [] } });
    await renderBOMTable();
  });

  // Search console
  document.getElementById('btn-search-start').addEventListener('click', handleSearchStart);
}

// ── Agent BOM Parsing ──────────────────────────────────────
async function handleParseBOM() {
  const textarea = document.getElementById('import-textarea');
  const statusEl = document.getElementById('import-status');
  const bomText = textarea.value.trim();

  if (!bomText) {
    statusEl.textContent = '请先粘贴 BOM 内容';
    statusEl.className = 'status-msg error';
    return;
  }

  statusEl.textContent = 'Agent 正在解析...';
  statusEl.className = 'status-msg loading';
  document.getElementById('btn-parse').disabled = true;

  try {
    const resp = await chrome.runtime.sendMessage({
      type: 'agent:parse-bom',
      payload: { bomText }
    });

    if (resp.error) throw new Error(resp.error);

    const { bom, rawResponse } = resp;

    // Save parsed BOM to storage
    await chrome.runtime.sendMessage({ type: 'bom:replace-parts', payload: bom.parts });
    await chrome.runtime.sendMessage({
      type: 'bom:save',
      payload: { ...bom, parts: bom.parts }
    });

    statusEl.textContent = `✓ 解析完成！${bom.parts.length} 个零件 (${rawResponse.model})`;
    statusEl.className = 'status-msg success';

    // Check for parts with notes (ambiguities)
    const ambiguous = bom.parts.filter(p => p.notes);
    if (ambiguous.length > 0) {
      const question = ambiguous.map(p => `• ${p.name}: ${p.notes}`).join('\n');
      document.getElementById('clarify-question').textContent =
        `以下 ${ambiguous.length} 个零件存在歧义，Agent 已做了猜测：\n\n${question}\n\n需要修改吗？`;
      document.getElementById('clarify-dialog').classList.remove('hidden');
      document.getElementById('clarify-answer').value = '';
    }

    await renderBOMTable();
    setTimeout(() => {
      document.getElementById('import-modal').classList.add('hidden');
      statusEl.textContent = '';
      statusEl.className = 'status-msg';
    }, 1500);

  } catch (err) {
    statusEl.textContent = '✗ ' + err.message;
    statusEl.className = 'status-msg error';
  } finally {
    document.getElementById('btn-parse').disabled = false;
  }
}

async function handleClarifySend() {
  const answer = document.getElementById('clarify-answer').value.trim();
  if (!answer) return;

  document.getElementById('btn-clarify-send').disabled = true;
  document.getElementById('btn-clarify-send').textContent = '处理中...';

  try {
    const bom = await chrome.runtime.sendMessage({ type: 'bom:load' });
    const resp = await chrome.runtime.sendMessage({
      type: 'agent:clarify',
      payload: { bom, question: answer }
    });

    // TODO: parse clarification response and merge
    document.getElementById('clarify-dialog').classList.add('hidden');
  } catch (err) {
    alert('Clarify error: ' + err.message);
  } finally {
    document.getElementById('btn-clarify-send').disabled = false;
    document.getElementById('btn-clarify-send').textContent = '发送';
  }
}

// ── Search Console ─────────────────────────────────────────
async function handleSearchStart() {
  const site = document.getElementById('site-select').value;
  const out = document.getElementById('console-output');

  // Check agent config
  const configured = await chrome.runtime.sendMessage({ type: 'agent:is-configured' });
  if (!configured) {
    out.innerHTML = '<div class="console-line"><span class="error">✗ Agent 未配置。</span> 请在扩展选项页 (右键图标 → Options) 设置 OpenRouter API Key。</div>';
    return;
  }

  // Check BOM has pending parts
  const stats = await chrome.runtime.sendMessage({ type: 'bom:stats' });
  if (stats.pending === 0) {
    out.innerHTML = '<div class="console-line"><span class="warn">⚠ 没有待搜索的零件。</span> 所有零件已标价或跳过。</div>';
    return;
  }

  logConsole(out, 'info', `启动 ${site} 搜索 — ${stats.pending} 个待搜索零件`);

  // TODO (Phase 3): kick off search loop via content script
  // For now, show placeholder
  logConsole(out, 'warn', '搜索流程尚未实现 (Phase 3)');
  logConsole(out, 'info', '已确认 OpenRouter 连接正常，BOM 中有待搜索零件');
  logConsole(out, 'info', '下一步：实现 Octopart content script + 搜索状态机');
}

function logConsole(el, level, msg) {
  const ts = new Date().toLocaleTimeString('en-US', { hour12: false });
  const line = document.createElement('div');
  line.className = 'console-line';
  line.innerHTML = `<span class="ts">[${ts}]</span> <span class="${level}">${escHtml(msg)}</span>`;
  el.appendChild(line);
  el.scrollTop = el.scrollHeight;
}

// ── Optimize Tab ───────────────────────────────────────────
async function renderOptimizeTab() {
  const el = document.getElementById('optimize-results');
  const stats = await chrome.runtime.sendMessage({ type: 'bom:stats' });

  if (stats.priced === 0) {
    el.innerHTML = '<div class="optimize-placeholder">还没有已标价的零件。先在 Octopart 搜索并标价。</div>';
    return;
  }

  // Placeholder — will call optimizer in Phase 4
  el.innerHTML = `<div class="optimize-placeholder">
    ${stats.priced} 个零件已标价。优化器将在 Phase 4 实现。<br>
    届时将调用独立 Agent 运行组合优化，点击 "重新计算" 即可。
  </div>`;
}

// Bind optimize button
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btn-optimize')?.addEventListener('click', renderOptimizeTab);
});

// ── Helpers ────────────────────────────────────────────────
function escHtml(s) {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

function escAttr(s) {
  return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
