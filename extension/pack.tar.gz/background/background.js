// Background Service Worker
// Routes messages between popup, content scripts, and Agent.
// Path: /root/bom-to-cart-extension/background/background.js

importScripts('/lib/bom-store.js', '/lib/agent.js');

// ── Message Router ──────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const { type, payload } = msg || {};

  switch (type) {
    // Agent calls
    case 'agent:parse-bom':
      handleParseBOM(payload).then(sendResponse, e => sendResponse({ error: e.message }));
      return true; // async

    case 'agent:clarify':
      handleClarify(payload).then(sendResponse, e => sendResponse({ error: e.message }));
      return true;

    case 'agent:handle-exception':
      handleException(payload).then(sendResponse, e => sendResponse({ error: e.message }));
      return true;

    // BOM CRUD (delegated to BOMStore)
    case 'bom:load':
      BOMStore.load().then(sendResponse);
      return true;

    case 'bom:save':
      BOMStore.save(payload).then(sendResponse);
      return true;

    case 'bom:add-part':
      BOMStore.addPart(payload).then(sendResponse);
      return true;

    case 'bom:update-part':
      BOMStore.updatePart(payload.id, payload.changes).then(sendResponse);
      return true;

    case 'bom:remove-part':
      BOMStore.removePart(payload).then(sendResponse, e => sendResponse({ error: e.message }));
      return true;

    case 'bom:replace-parts':
      BOMStore.replaceParts(payload).then(sendResponse);
      return true;

    case 'bom:stats':
      BOMStore.stats().then(sendResponse);
      return true;

    // Agent config
    case 'agent:get-config':
      Agent.getConfig().then(sendResponse);
      return true;

    case 'agent:set-config':
      Agent.setConfig(payload).then(sendResponse);
      return true;

    case 'agent:is-configured':
      Agent.isConfigured().then(sendResponse);
      return true;

    case 'agent:call':
      Agent.call(payload).then(sendResponse, e => sendResponse({ error: e.message }));
      return true;

    default:
      sendResponse({ error: `Unknown message type: ${type}` });
      return false;
  }
});

// ── Agent Handlers ──────────────────────────────────────────

const BOM_PARSE_SYSTEM = `You are a purchasing assistant that parses Bills of Materials into structured JSON.

Given a user's BOM in any format (markdown table, CSV, plain text, bullet list), extract each distinct part and return a JSON object matching this schema:

{
  "version": "1.0",
  "parts": [
    {
      "id": "uuid-string",
      "name": "Part name with key specs",
      "quantity": integer,
      "specs": {"key": "value"},
      "notes": "any clarifications needed or empty string",
      "status": "pending",
      "prices": {}
    }
  ]
}

Rules:
- Each part.id must be a unique UUID v4.
- Include key specifications in the name (e.g., "M3 hex standoff, 20mm, brass").
- Put additional specs in the specs object.
- Set notes to "" if no clarification needed. If a part is ambiguous (missing size/length/material etc.), note the ambiguity in "notes" and make your best guess for the specs.
- quantity must be a positive integer. Default to 1 if not specified.
- DO NOT include markdown code fences. Output raw JSON only.
- If the BOM is empty or unparseable, return {"version":"1.0","parts":[]}.`;

async function handleParseBOM({ bomText }) {
  const result = await Agent.call({
    systemPrompt: BOM_PARSE_SYSTEM,
    userMessage: `Parse this BOM into structured JSON:\n\n${bomText}`,
    jsonMode: true,
    temperature: 0.05
  });

  // Parse the JSON response
  let parsed;
  try {
    parsed = JSON.parse(result.content);
  } catch {
    // Try to extract JSON from markdown code fences
    const match = result.content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
    if (match) {
      parsed = JSON.parse(match[1]);
    } else {
      throw new Error('Agent returned invalid JSON');
    }
  }

  // Normalize
  parsed.parts = (parsed.parts || []).map(p => ({
    id: p.id || uuid(),
    name: p.name || 'Unknown Part',
    quantity: Math.max(1, parseInt(p.quantity) || 1),
    specs: p.specs || {},
    notes: p.notes || '',
    status: 'pending',
    prices: {},
    octopart_url: null,
    selected_platform: null
  }));

  parsed.version = '1.0';
  return { bom: parsed, rawResponse: result };
}

function uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

async function handleClarify({ bom, question }) {
  // Re-parse with clarification
  const result = await Agent.call({
    systemPrompt: BOM_PARSE_SYSTEM,
    userMessage: `Previous BOM parsing result:\n${JSON.stringify(bom, null, 2)}\n\nUser clarification: ${question}\n\nReturn updated parts array only (as JSON array, no wrapper).`,
    jsonMode: true,
    temperature: 0.1
  });
  return { clarification: result.content };
}

const EXCEPTION_SYSTEM = `You are a browser automation debugger. You are helping a Chrome extension that is trying to search for electronic parts on a shopping website (like Octopart). The automation hit an unexpected state.

Given:
- The current step it was trying to perform
- A description of what went wrong
- The current page URL

Respond with ONE of these actions as JSON:
{"action": "retry", "reason": "..."} — try the same step again
{"action": "skip", "reason": "..."} — skip this part, mark as not_found
{"action": "wait", "seconds": N, "reason": "..."} — wait N seconds then retry
{"action": "captcha", "reason": "..."} — a CAPTCHA is blocking, needs user
{"action": "navigate", "url": "...", "reason": "..."} — navigate to a different URL
{"action": "abort", "reason": "..."} — unrecoverable, stop the search loop

Be decisive. Prefer retry for transient issues (slow page load, popup). Prefer captcha when you see "security check", "CAPTCHA", "verify you're human".`;

async function handleException({ step, error, url, pageInfo }) {
  const result = await Agent.call({
    systemPrompt: EXCEPTION_SYSTEM,
    userMessage: [
      `Step being attempted: ${step}`,
      `Error/Issue: ${error}`,
      `Current URL: ${url}`,
      `Additional page info: ${pageInfo || 'none'}`
    ].join('\n'),
    jsonMode: true,
    temperature: 0.2
  });

  try {
    return { action: JSON.parse(result.content), rawResponse: result };
  } catch {
    return { action: { action: 'abort', reason: 'Could not parse agent response' }, rawResponse: result };
  }
}

console.log('[BOM-to-Cart] Background SW ready');
